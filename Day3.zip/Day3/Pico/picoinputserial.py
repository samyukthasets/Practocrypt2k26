import serial,sys
import threading

# Specify the COM port and baud rate
com_port = sys.argv[1]
baud_rate = sys.argv[2]
exit_flag = False

# Open the serial port
try:
    ser = serial.Serial(com_port, baud_rate, timeout=1)
    print(f"Connected to {com_port} at {baud_rate} baud rate.")
except serial.SerialException as e:
    print(f"Failed to connect to {com_port}: {e}")
    exit()

# Function to read from the serial port
def read_from_port():
    global exit_flag
    while not exit_flag:
        if ser.in_waiting > 0:
            data = ser.readline().decode('utf-8').rstrip()
            if data:
                print(data)

# Function to send user input to the serial port
def write_to_port():
    global exit_flag
    while not exit_flag:
        user_input = input()
        if user_input.lower() == "exit":
            exit_flag = True
            break
        ser.write(user_input.encode('utf-8') + b'\n')

# Create threads for reading and writing
try:
    read_thread = threading.Thread(target=read_from_port)
    write_thread = threading.Thread(target=write_to_port)

    read_thread.start()
    write_thread.start()

    # Wait for threads to finish
    read_thread.join()
    write_thread.join()
except KeyboardInterrupt:
    print("Exiting...")
finally:
    exit_flag = True
    ser.close()
    print("Serial port closed.")
