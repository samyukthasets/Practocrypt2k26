import params
import converse
import keccak
import sample
import NTT
import compress
import encode

import random


def infinity_norm(l,v):
    maxv=0
    for i in range(l):
        for j in range(params.MLDSA_N):
            if v[i][j]>params.MLDSA_Q//2:
                v[i][j]-=params.MLDSA_Q
            maxv=max(maxv,abs(v[i][j]))
    return maxv 


# Generates a public-private key pair from a seed.
# Input: Seed 𝜉 ∈ 𝔹32
# Output: Public key 𝑝𝑘 ∈ 𝔹32+32𝑘(bitlen (𝑞−1)−𝑑) and private key 𝑠𝑘 ∈ 𝔹32+32+64+32⋅((ℓ+𝑘)⋅bitlen (2𝜂)+𝑑𝑘)
def MLDSA_KeyGen_Internal(xi,variant=44):
    #select parameters based on variant
    if variant==44:
        k=params.MLDSA44_k
        l=params.MLDSA44_l
        eta=params.MLDSA44_eta
    elif variant==65:
        k=params.MLDSA65_k
        l=params.MLDSA65_l
        eta=params.MLDSA65_eta
    elif variant==87:
        k=params.MLDSA87_k
        l=params.MLDSA87_l
        eta=params.MLDSA87_eta
    else:
        print("Invalid variant selected. Please select 44, 65, or 87.")
        return None,None
    
    #expand seed
    seeds=bytearray(128)
    seeds[0:32]=xi
    seeds[32:33]=converse.IntegerToBytes(k,1)
    seeds[33:34]=converse.IntegerToBytes(l,1)
    keccak.shake256(seeds,128*8,seeds[:34])
    rho=seeds[:32]
    rho_prime=seeds[32:96]
    K=seeds[96:128]

    # 𝐀 is generated and stored in NTT representation as A_hat
    A_hat=sample.ExpandA(k,l,rho)
    
    # Sample s1 and s2
    s1,s2=sample.ExpandS(eta,k,l,rho_prime)
    
    # MLWE instance in NTT domain
    s1_hat=NTT.NTT_vec(s1)
    t_hat=NTT.MatrixVectorNTT(k,l,A_hat,s1_hat)
    t=NTT.iNTT_vec(t_hat)
    t=NTT.AddVectorNTT(k,t,s2)
    
    # PowerTwoRound is applied componentwise
    t1=[[0 for i in range(params.MLDSA_N)] for j in range(k)]
    t0=[[0 for i in range(params.MLDSA_N)] for j in range(k)]
    for i in range(k):
        for j in range(params.MLDSA_N):
            t1[i][j],t0[i][j]=compress.Power2Round(t[i][j])
    
    # encode pk and sk
    pk=encode.pkEncode(eta,k,rho,t1)
    tr=bytearray(64)
    keccak.shake256(tr,64*8,pk)
    sk=encode.skEncode(eta,k,l,rho,K,tr,s1,s2,t0)
    
    return pk,sk



# Deterministic algorithm to generate a signature for a formatted message 𝑀′.
# Input: Private key 𝑠𝑘 ∈ 𝔹32+32+64+32⋅((ℓ+𝑘)⋅bitlen (2𝜂)+𝑑𝑘), formatted message 𝑀′ ∈ {0, 1}∗, and
# per message randomness or dummy variable 𝑟𝑛𝑑 ∈ 𝔹32.
# Output: Signature 𝜎 ∈ 𝔹𝜆/4+ℓ⋅32⋅(1+bitlen (𝛾1−1))+𝜔+𝑘.
def MLDSA_Sign_Internal(sk,M_prime,rnd,variant=44):
    #select parameters based on variant
    if variant==44:
        k=params.MLDSA44_k
        l=params.MLDSA44_l
        eta=params.MLDSA44_eta
        gamma1=params.MLDSA44_gamma1
        gamma2=params.MLDSA44_gamma2
        lambda_c=params.MLDSA44_lambda
        tao=params.MLDSA44_tao
        beta=params.MLDSA44_beta
        omega=params.MLDSA44_omega
    elif variant==65:
        k=params.MLDSA65_k
        l=params.MLDSA65_l
        eta=params.MLDSA65_eta
        gamma1=params.MLDSA65_gamma1
        gamma2=params.MLDSA65_gamma2
        lambda_c=params.MLDSA65_lambda
        tao=params.MLDSA65_tao
        beta=params.MLDSA65_beta
        omega=params.MLDSA65_omega
    elif variant==87:
        k=params.MLDSA87_k
        l=params.MLDSA87_l
        eta=params.MLDSA87_eta
        gamma1=params.MLDSA87_gamma1
        gamma2=params.MLDSA87_gamma2
        lambda_c=params.MLDSA87_lambda
        tao=params.MLDSA87_tao
        beta=params.MLDSA87_beta
        omega=params.MLDSA87_omega
    else:
        print("Invalid variant selected. Please select 44, 65, or 87.")
        return None,None
    
    #decode sk
    rho,K,tr,s1,s2,t0=encode.skDecode(eta,k,l,sk)

    # to NTT domain
    s1_hat=NTT.NTT_vec(s1)                                                      # s1_hat l*256
    s2_hat=NTT.NTT_vec(s2)                                                      # s2_hat k*256
    t0_hat=NTT.NTT_vec(t0)                                                      # t0_hat k*256  

    # recover A_hat
    A_hat=sample.ExpandA(k,l,rho)                                               # A_hat k*l*256 

    # 𝜇 ← H(BytesToBits(𝑡𝑟)||𝑀′, 64)
    mu=bytearray(64)                                                             # mu 64 bytes    
    ctx=keccak.shake256_inc_init()
    keccak.shake256_inc_absorb(ctx,tr)
    keccak.shake256_inc_absorb(ctx,M_prime)
    keccak.shake256_inc_finalize(ctx)
    keccak.shake256_inc_squeeze(mu,64,ctx)

    rho_2prime=bytearray(64)                                                   # rho_2prime 64 bytes
    keccak.shake256(rho_2prime,64*8,K+rnd+mu)
    kappa=0
    z,h=None,None
    while z is None and h is None:
        y=sample.ExpandMask(l,gamma1,rho_2prime,kappa)                              # y l*256
        #𝐰 ← NTT−1(𝐀 ∘̂ NTT(𝐲))   𝐰1 ← HighBits(𝐰)    signer’s commitment
        y_hat=NTT.NTT_vec(y)                                                     # y_hat l*256
        w_hat=NTT.MatrixVectorNTT(k,l,A_hat,y_hat)                                  # w_hat k*256
        w=NTT.iNTT_vec(w_hat)                                                    # w k*256
        w1=[[0 for i in range(params.MLDSA_N)] for j in range(k)]
        for i in range(k):
            for j in range(params.MLDSA_N):
                w1[i][j]=compress.HighBits(gamma2,w[i][j])                        # w1 k*256
        
        #sample c
        lenc_tilde=lambda_c//4
        c_tilde=bytearray(lenc_tilde)
        keccak.shake256(c_tilde,lenc_tilde*8,mu+encode.w1Encode(gamma2,k,w1))
        c=sample.SampleInBall(tao,c_tilde)                                         # c poly 256
        c_hat=NTT.NTT_montgomery(c)                                             # c_hat poly 256
        
        #compute z
        z=NTT.ScalarVectorNTT(l,c_hat,s1_hat)                                     # z l*256
        z=NTT.iNTT_vec(z)
        z=NTT.AddVectorNTT(l,y,z)                                               # z l*256
        
        #conditional checks
        cs2=NTT.ScalarVectorNTT(k,c_hat,s2_hat)
        cs2=NTT.iNTT_vec(cs2)                                                    # cs2 k*256
        r0_poly=NTT.SubVectorNTT(k,w,cs2)                                         # r0_poly k*256
        r0=[[0 for i in range(params.MLDSA_N)] for j in range(k)]
        for i in range(k):
            for j in range(params.MLDSA_N):
                r0[i][j]=compress.LowBits(gamma2,r0_poly[i][j])
        max_z=infinity_norm(l,z)
        max_r0=infinity_norm(k,r0)
        if max_z>=gamma1-beta or max_r0>=gamma2-beta:
            z,h=None,None
        else:
            ct0=NTT.ScalarVectorNTT(k,c_hat,t0_hat)                                   # ct0 k*256
            ct0=NTT.iNTT_vec(ct0)
            zeros=[[0 for i in range(params.MLDSA_N)] for j in range(k)]
            minus_ct0=NTT.SubVectorNTT(k,zeros,ct0)                                  # minus_ct0 k*256
            w_approx=NTT.AddVectorNTT(k,r0_poly,ct0)
            h=compress.MakeHints_vec(k,gamma2,minus_ct0,w_approx)                       # h k*256
            max_ct0=infinity_norm(k,ct0)
            hw_h=0
            for i in range(k):
                for j in range(params.MLDSA_N):
                    hw_h+=h[i][j]
            if max_ct0>=gamma2 or hw_h>omega:
                z,h=None,None
        kappa+=l
    sig=encode.sigEncode(omega,k,l,gamma1,c_tilde,z,h)
    return sig


# Internal function to verify a signature 𝜎 for a formatted message 𝑀′.
# Input: Public key 𝑝𝑘 ∈ 𝔹32+32𝑘(bitlen (𝑞−1)−𝑑) and message 𝑀′ ∈ {0, 1}∗.
# Input: Signature 𝜎 ∈ 𝔹𝜆/4+ℓ⋅32⋅(1+bitlen (𝛾1−1))+𝜔+𝑘.
# Output: Boolean
def MLDSA_Verify_Internal(pk,M_prime,sig,variant=44):
    #select parameters based on variant
    if variant==44:
        k=params.MLDSA44_k
        l=params.MLDSA44_l
        eta=params.MLDSA44_eta
        gamma1=params.MLDSA44_gamma1
        gamma2=params.MLDSA44_gamma2
        lambda_c=params.MLDSA44_lambda
        tao=params.MLDSA44_tao
        beta=params.MLDSA44_beta
        omega=params.MLDSA44_omega
    elif variant==65:
        k=params.MLDSA65_k
        l=params.MLDSA65_l
        eta=params.MLDSA65_eta
        gamma1=params.MLDSA65_gamma1
        gamma2=params.MLDSA65_gamma2
        lambda_c=params.MLDSA65_lambda
        tao=params.MLDSA65_tao
        beta=params.MLDSA65_beta
        omega=params.MLDSA65_omega
    elif variant==87:
        k=params.MLDSA87_k
        l=params.MLDSA87_l
        eta=params.MLDSA87_eta
        gamma1=params.MLDSA87_gamma1
        gamma2=params.MLDSA87_gamma2
        lambda_c=params.MLDSA87_lambda
        tao=params.MLDSA87_tao
        beta=params.MLDSA87_beta
        omega=params.MLDSA87_omega
    else:
        print("Invalid variant selected. Please select 44, 65, or 87.")
        return None,None
    
    #decode pk
    rho,t1=encode.pkDecode(eta,k,pk)                                              # rho 32 bytes, t1 k*256

    #decode signature
    c_tilde,z,h=encode.sigDecode(lambda_c,omega,k,l,gamma1,sig)

    if h is None:
        return False
    
    #recover A_hat and tr
    A_hat=sample.ExpandA(k,l,rho)                                               # A_hat k*l*256 
    tr=bytearray(64)                                                             # tr 64 bytes
    keccak.shake256(tr,64*8,pk)

    # recover mu
    mu=bytearray(64)                                                             # mu 64 bytes    
    ctx=keccak.shake256_inc_init()
    keccak.shake256_inc_absorb(ctx,tr)
    keccak.shake256_inc_absorb(ctx,M_prime)
    keccak.shake256_inc_finalize(ctx)
    keccak.shake256_inc_squeeze(mu,64,ctx)

    #recover c
    c=sample.SampleInBall(tao,c_tilde)

    # 𝐰′approx ← NTT−1(𝐀 ∘̂ NTT(𝐳) − NTT(𝑐) ∘ NTT(𝐭1 ⋅ 2𝑑)) 
    z_hat=NTT.NTT_vec(z)                                                         # z_hat l*256
    w_approx_prime=NTT.MatrixVectorNTT(k,l,A_hat,z_hat)                            # w_approx_prime k*256
    ct1_mul2d=[[0 for i in range(params.MLDSA_N)] for j in range(k)]
    for i in range(k):
        for j in range(params.MLDSA_N):
            ct1_mul2d[i][j]=t1[i][j]<<params.MLDSA_D                                       # t1*2^d
    ct1_mul2d=NTT.NTT_vec(ct1_mul2d)                                            # NTT(t1*2^d) k*256
    ct1_mul2d=NTT.ScalarVectorNTT(k,NTT.NTT_montgomery(c),ct1_mul2d)                # NTT(c)*NTT(t1*2^d) k*256))
    w_approx_prime=NTT.SubVectorNTT(k,w_approx_prime,ct1_mul2d)                     # w_approx_prime k*256
    w_approx_prime=NTT.iNTT_vec(w_approx_prime)                                         # w_approx k*256
    w1_prime=compress.UseHints_vec(k,gamma2,h,w_approx_prime)                              # w1 k*256)
    lenc_tilde=lambda_c//4
    c_tilde_prime=bytearray(lenc_tilde)
    keccak.shake256(c_tilde_prime,lenc_tilde*8,mu+encode.w1Encode(gamma2,k,w1_prime))
    z_max=infinity_norm(l,z)
    return z_max<gamma1-beta and c_tilde==c_tilde_prime



def MLDSA_KeyGen(variant=44):
    xi= bytearray(random.getrandbits(8) for _ in range(32))
    if xi==None:
        print("Error generating random bytes for xi.")
        return None,None
    return MLDSA_KeyGen_Internal(xi,variant)

def MLDSA_Sign(sk,M,ctx,variant=44):
    if len(ctx)>255:
        print("Error: context too long.")
        return None
    rnd=bytearray(random.getrandbits(8) for _ in range(32))
    if rnd==None:
        print("Error generating random bytes for rnd.")
        return None
    M_prime=converse.IntegerToBytes(0,1)+converse.IntegerToBytes(len(ctx),1)+ctx+M
    return MLDSA_Sign_Internal(sk,M_prime,rnd,variant)

def MLDSA_Verify(pk,M,sig,ctx,variant=44):
    if len(ctx)>255:
        print("Error: context too long.")
        return None
    M_prime=converse.IntegerToBytes(0,1)+converse.IntegerToBytes(len(ctx),1)+ctx+M
    return MLDSA_Verify_Internal(pk,M_prime,sig,variant)




if __name__ == '__main__':

    # ctx= bytearray(random.randint(1, 255) for _ in range(255)) #optional
    
    M= b"Hi User"
    pk,sk=MLDSA_KeyGen(variant=65)
    
    print("Public Key :",pk.hex())
    print("\nPrivate Key : ",sk.hex())

    print(len(sk),len(pk))

    sig=MLDSA_Sign(sk,M,b"",variant=65)

    print(len(sig))

    print("\nSignature : ",sig.hex())

    validity=MLDSA_Verify(pk,M,sig,bytearray(b""),variant=65)
    if validity:
        print("success")
    else:
        print("failed")


