import math
import random
from typing import List, Union

import numpy as np
from Crypto.Util.number import getPrime, getRandomNBitInteger
from numpy.polynomial.polynomial import polyadd, polymul
import basic_op
import bgv
import time
import cipher_op



#Polynomial Degree n
n = 2**5
# q : Cipher Text modulus
coef_modulus = getRandomNBitInteger(32)
plaintext_modulus = 7

poly_modulus = basic_op.init_poly_modulus(n)
print("\nPlaintext modulus \t: ", plaintext_modulus)
print("Degree , n \t\t: ", n)
print("coef_modulus \t\t: ", coef_modulus)
print("poly_modulus \t\t: ", poly_modulus)

# Generate secret key
sk = basic_op.QuotientRingPoly([1,0], coef_modulus, poly_modulus)