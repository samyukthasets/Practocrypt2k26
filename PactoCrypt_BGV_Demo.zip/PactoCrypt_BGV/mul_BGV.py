import math
import random
from typing import List, Union

import numpy as np
from Crypto.Util.number import getPrime, getRandomNBitInteger
from numpy.polynomial.polynomial import polyadd, polymul
import basic_op
import bgv
import time
import cipher_op
    

n = 2**5
# q
coef_modulus = getRandomNBitInteger(32)
# coef_modulus = 211
# coef_modulus = getrandbits(12)
plaintext_modulus = 7

poly_modulus = basic_op.init_poly_modulus(n)
print("\nplaintext modulus : ", plaintext_modulus)
print("Coef Modulus : ", coef_modulus)
print("Poly Modulus : :", poly_modulus)

start = time.perf_counter()
# Generate secret key
sk = bgv.gen_secret_key(coef_modulus, poly_modulus)

end = time.perf_counter()

time_sk_gen = (end-start)*1_000_000


print("\nSecret Key : ", sk.coef, "\n")

start = time.perf_counter()

# Generate public key pair
pk0, pk1 = bgv.gen_public_key(sk, coef_modulus, poly_modulus, plaintext_modulus)

end = time.perf_counter()

time_pk_gen = (end-start)*1_000_000

print ("Public Key\n pk0: ", pk0.coef) 
print( "Pk1 : ", pk1.coef)

msg = basic_op.random_uniform_poly(coef_modulus, poly_modulus, high=plaintext_modulus)
msg2 = basic_op.random_uniform_poly(coef_modulus, poly_modulus, high=plaintext_modulus)

print("\n\nMessages:\nm1 : ", msg.coef)
print("m2 : ", msg2.coef)

start = time.perf_counter()

c1_0, c1_1 = bgv.encrypt(msg, pk0, pk1, coef_modulus, poly_modulus, plaintext_modulus)

end = time.perf_counter()
time_enc = (end-start)*1_000_000

c2_0, c2_1 = bgv.encrypt(msg2, pk0, pk1, coef_modulus, poly_modulus, plaintext_modulus)

print("\nCipher Texts\nc1_0 ", c1_0.coef, "\n\nc1_1 : ", c1_1.coef)
print("\n\nc2_0 ", c2_0.coef, "\n\nc2_1 : ", c2_1.coef)

### Addition ####

start = time.perf_counter()
msg_res = (msg + msg2) % plaintext_modulus
end = time.perf_counter()

time_p_add = (end-start)*1_000_000

start = time.perf_counter()
c0_res, c1_res = cipher_op.add(c1_0, c1_1, c2_0, c2_1)
end = time.perf_counter()

time_c_add = (end-start)*1_000_000



print("\n\nAddition \n m1+m2 : ", msg_res.coef)
print("c1_0+c2_0 : ", c0_res.coef)
print("c1_1+c2_1 : ", c1_res.coef)

start = time.perf_counter()

# Decrypt the message and return the noise
msg_dec         = bgv.decrypt(c1_0, c1_1, sk, plaintext_modulus)

end = time.perf_counter()

time_dec = (end-start)*1_000_000

msg2_dec        = bgv.decrypt(c2_0, c2_1, sk, plaintext_modulus )
msg_res_decr    = bgv.decrypt(c0_res, c1_res, sk, plaintext_modulus)

print("\nResult\nAfter Decryption : ", msg_res_decr.coef.astype(int))
print("Original\t : ", msg_res.coef.astype(int))
if msg_res == msg_res_decr and msg_dec == msg and msg2_dec == msg2:
    print("\t\t ** All corresponding Polynomials are equal **")
else:
    print("Polynomials are different")


#### Multiplication #######


start = time.perf_counter()

msg_res = (msg * msg2) % plaintext_modulus
end = time.perf_counter()

time_p_mul = (end-start)*1_000_000

start = time.perf_counter()

c0_res, c1_res, c2_res = cipher_op.mul(c1_0, c1_1, c2_0, c2_1)

end = time.perf_counter()

time_c_mul = (end-start)*1_000_000

start = time.perf_counter()
msg_res_decr = cipher_op.decrypt_quad(
    c0_res, c1_res, c2_res, sk, plaintext_modulus
)
end = time.perf_counter()
time_mul_dec_quad = (end-start)*1_000_000


print("\n\nMultiplication :")
print("Cipher Texts\nC0 :", c0_res.coef)
print("C1 :", c1_res.coef)
print("C2 :", c2_res.coef)
print("\nResult\nOriginal\t: ",msg_res.coef)
print("Decrypted \t: ", msg_res_decr.coef)
if msg_res == msg_res_decr:
    print("\t\t---- Both are same ----")
else:
    print("\t\t\t!!!!!Both are different")


print("\n\n====== Elapsed Time in µs ========\n")
print("Key Generation \n\tFor Secrect Key\t: ", time_sk_gen, "\n\tFor Public Key\t: ", time_pk_gen)
print("Encryption of msg 1 \t: ", time_enc)
print("Decryption of msg 1 \t: ", time_dec)

print("\nPlaintext Addition\t: ", time_p_add)
print("Cipher Addition\t\t: ", time_c_add)
print("\nPlaintext Multiplication\t: ", time_p_mul)
print("Cipher Multiplication\t\t: ", time_c_mul)
print("Multiplied Cipher Decryption\t: ", time_mul_dec_quad, "\n\n==== END ====\n")
  