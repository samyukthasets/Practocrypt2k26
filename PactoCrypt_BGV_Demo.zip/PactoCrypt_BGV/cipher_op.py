import math
import random
from typing import List, Union

import numpy as np
from Crypto.Util.number import getPrime, getRandomNBitInteger
from numpy.polynomial.polynomial import polyadd, polymul
import basic_op
import bgv
import time

def add(c0, c1, c0_, c1_):
    return c0 + c0_, c1 + c1_


def mul(c0, c1, c0_, c1_):
    return c0 * c0_, c0 * c1_ + c1 * c0_, c1 * c1_


def decrypt_quad(c0, c1, c2, sk, plaintext_modulus):
    # Evaluate the quadratic equation
    msg = c0 + c1 * sk + c2 * sk * sk
    noise = np.max(np.abs(msg.coef))
    return msg % plaintext_modulus

def relinearize(
    c0: basic_op.QuotientRingPoly, 
    c1: basic_op.QuotientRingPoly, 
    c2: basic_op.QuotientRingPoly, 
    ek0: basic_op.QuotientRingPoly, 
    ek1: basic_op.QuotientRingPoly):
   
    tmp1 = c2 * ek0
    tmp2 = c2 * ek1
    
    c0_hat = c0 + tmp1
    c1_hat = c1 + tmp2

    return c0_hat, c1_hat
   
