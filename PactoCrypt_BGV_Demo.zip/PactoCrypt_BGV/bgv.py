import math
import random
from typing import List, Union

import numpy as np
from Crypto.Util.number import getPrime, getRandomNBitInteger
from numpy.polynomial.polynomial import polyadd, polymul
import time
import basic_op

def gen_secret_key(coef_modulus: int, poly_modulus: np.ndarray):
    # Draw the secret
    s = basic_op.random_ternary_poly(coef_modulus, poly_modulus)
    # print ("sk : ", s)
    return s
 

def gen_public_key(
    sk: basic_op.QuotientRingPoly,
    coef_modulus: int,
    poly_modulus: np.ndarray,
    plaintext_modulus: int,
):
    # Generate noise e
    e = basic_op.random_normal_poly(coef_modulus, poly_modulus)
    # Generate unifrom poly a
    a = basic_op.random_uniform_poly(coef_modulus, poly_modulus)
    # RLWE instance b
    b = a * sk + e * plaintext_modulus
    # print("e : ", e, "\na : ", a, "\npk0 : ", b, "\npk1 : ", -a)    
      
    return -b, a



def encrypt(
    msg: basic_op.QuotientRingPoly,
    pk0: basic_op.QuotientRingPoly,
    pk1: basic_op.QuotientRingPoly,
    coef_modulus: int,
    poly_modulus: np.ndarray,
    plaintext_modulus: int,
):
    u = basic_op.random_ternary_poly(coef_modulus, poly_modulus)
    e0 = basic_op.random_normal_poly(coef_modulus, poly_modulus)
    e1 = basic_op.random_normal_poly(coef_modulus, poly_modulus)
    # Mask the message with a rlwe instance (b * r + te)
    c0 = pk0 * u + e0 * plaintext_modulus + msg
    c1 = pk1 * u + e1 * plaintext_modulus
    # print("u: ", u, "\ne0 : ", e0, "\ne1 : ", e1, "\nc0 : ", c0, "\nc1 : ", c1)
    return c0, c1


def decrypt(
    c0: basic_op.QuotientRingPoly,
    c1: basic_op.QuotientRingPoly,
    sk: basic_op.QuotientRingPoly,
    plaintext_modulus: int,
   
):
    msg = c0 + c1 * sk
    return msg % plaintext_modulus

   
   

if __name__ == "__main__":


    #Polynomial Degree n
    n = 2**5
    # q : Cipher Text modulus
    coef_modulus = getRandomNBitInteger(32)
    plaintext_modulus = 7

    poly_modulus = basic_op.init_poly_modulus(n)
    print("\nPlaintext modulus \t: ", plaintext_modulus)
    print("Degree , n \t\t: ", n)
    print("coef_modulus \t\t: ", coef_modulus)
    print("poly_modulus \t\t: ", poly_modulus)

    # Generate secret key
    sk = gen_secret_key(coef_modulus, poly_modulus)


    print("\nSecret Key : ", sk.coef, "\n")

    # Generate public key pair
    pk0, pk1 = gen_public_key(sk, coef_modulus, poly_modulus, plaintext_modulus)


    print ("Public Key\n pk0: ", pk0.coef) 
    print( "Pk1 : ", pk1.coef)



    # Generate random small message in R_t
    msg = basic_op.random_uniform_poly(coef_modulus, poly_modulus, high=plaintext_modulus)

    print("\nMessage : " , msg.coef, "\n")

    # Encrypt the message into two ciphertexts
    c0, c1 = encrypt(msg, pk0, pk1, coef_modulus, poly_modulus, plaintext_modulus)



    print("Cipher Text :\nC0 : ", c0.coef)
    print("C1 : " ,c1.coef, "\n")


    # Decrypt the message and return the noise
    msg_decr = decrypt(c0, c1, sk, plaintext_modulus)

  
    print("\nDecrypted Message\t: ", msg_decr.coef)
    print("\tOriginal\t: ", msg.coef)
    if msg == msg_decr:
        print("\n\t\t** Both are same **")
    else:
        print("\n\t !!!!! Polynomials are different")

