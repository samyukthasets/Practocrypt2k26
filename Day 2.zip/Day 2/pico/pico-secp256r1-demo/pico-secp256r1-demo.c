/*
 * secp256r1 + SHA3 demo for Raspberry Pi Pico 2 (RP2350)
 * Uses Pico SDK, micro‑ecc, and a SHA3 implementation.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Pico SDK headers
#include "pico/stdlib.h"
#include "pico/rand.h"
#include "hardware/watchdog.h"

// micro‑ecc and SHA3 (external)
#include "uECC.h"
#include "sha3.h"

#define MAX_INPUT_SIZE 1024
#define MAX_MSG_LEN    256

uint8_t last_signature[64];
char last_message[MAX_MSG_LEN];
int last_msg_len = 0;

// Global keys for Alice and Bob
uint8_t alice_priv[32], alice_pub[64];
uint8_t bob_priv[32], bob_pub[64];
uint8_t secret_alice[32], secret_bob[32];
uECC_Curve curve;
int keys_generated = 0;

// ---------- Pico random generator (using TRNG) ----------
void pico_fill_random(void *buf, size_t len) {
    uint8_t *bytes = (uint8_t *)buf;
    size_t remaining = len;
    while (remaining >= 4) {
        uint32_t rnd = get_rand_32();
        *bytes++ = (rnd >> 0) & 0xFF;
        *bytes++ = (rnd >> 8) & 0xFF;
        *bytes++ = (rnd >> 16) & 0xFF;
        *bytes++ = (rnd >> 24) & 0xFF;
        remaining -= 4;
    }
    if (remaining > 0) {
        uint32_t rnd = get_rand_32();
        for (size_t i = 0; i < remaining; i++) {
            bytes[i] = (rnd >> (i * 8)) & 0xFF;
        }
    }
}

// ---------- Restart via watchdog ----------
void pico_restart(void) {
    printf("\nRestarting...\n");
    fflush(stdout);
    sleep_ms(1000);
    watchdog_enable(1, 1);   // enable watchdog with 1 ms timeout
    while (1);               // wait for reset
}

// ---------- Helper: print hex ----------
void print_hex(const char *label, const uint8_t *data, size_t len) {
    printf("%s: ", label);
    for (size_t i = 0; i < len; i++) {
        printf("%02x", data[i]);
    }
    printf("\n");
}

// ---------- Helper: compare buffers ----------
int compare_buffers(const uint8_t *a, const uint8_t *b, size_t len) {
    for (size_t i = 0; i < len; i++) {
        if (a[i] != b[i]) return 0;
    }
    return 1;
}

// ---------- Read a line from stdin (USB serial) ----------
int read_line(char *buffer, int max_len) {
    int len = 0;
    int ch;
    while (len < max_len - 1) {
        ch = getchar_timeout_us(100000); // 100 ms timeout
        if (ch == PICO_ERROR_TIMEOUT) continue;
        if (ch == '\r' || ch == '\n') {
            if (len > 0) break;
            continue;
        }
        if (ch == '\b' || ch == 127) {
            if (len > 0) {
                len--;
                printf("\b \b");
                fflush(stdout);
            }
            continue;
        }
        buffer[len++] = (char)ch;
        printf("%c", ch);
        fflush(stdout);
    }
    buffer[len] = '\0';
    printf("\n");
    return len;
}

// ---------- Display menu ----------
void display_menu() {
    printf("\n===========================================\n");
    printf("   Pico 2 secp256r1 Demo\n");
    printf("===========================================\n");
    printf("1. Generate Alice & Bob Keys\n");
    printf("2. Compute Shared Secret (ECDH)\n");
    printf("3. Sign Message with Alice's Key (ECDSA)\n");
    printf("4. Verify Signature with Alice's Public Key\n");
    printf("5. View Current Keys\n");
    printf("6. Exit (Restart)\n");
    printf("===========================================\n");
    printf("Enter choice: ");
}

// ---------- Generate keys (using hardware random) ----------
void generate_keys() {
    printf("\n--- Generating ECC Key Pairs ---\n");

    curve = uECC_secp256r1();

    // Alice
    uint8_t alice_seed[32];
    pico_fill_random(alice_seed, 32);
    uECC_make_key(alice_pub, alice_priv, curve);
    printf("\n✅ Alice's keys generated\n");
    print_hex("Alice Private Key", alice_priv, 32);
    print_hex("Alice Public Key ", alice_pub, 64);

    // Bob
    uint8_t bob_seed[32];
    pico_fill_random(bob_seed, 32);
    uECC_make_key(bob_pub, bob_priv, curve);
    printf("\n✅ Bob's keys generated\n");
    print_hex("Bob Private Key", bob_priv, 32);
    print_hex("Bob Public Key ", bob_pub, 64);

    keys_generated = 1;
    printf("\n✅ Key generation complete!\n");
}

// ---------- Compute shared secret (ECDH) ----------
void compute_shared_secret() {
    if (!keys_generated) {
        printf("\n❌ Error: Keys not generated yet! Please select option 1 first.\n");
        return;
    }

    printf("\n--- Computing Shared Secret (ECDH) ---\n");

    uECC_shared_secret(bob_pub, alice_priv, secret_alice, curve);
    uECC_shared_secret(alice_pub, bob_priv, secret_bob, curve);

    print_hex("Shared Secret (Alice)", secret_alice, 32);
    print_hex("Shared Secret (Bob)  ", secret_bob, 32);

    if (compare_buffers(secret_alice, secret_bob, 32)) {
        printf("\n✅ Alice and Bob now share the SAME secret key!\n");
    } else {
        printf("\n❌ Shared secrets do not match!\n");
    }
}

// ---------- Sign a message (ECDSA) ----------
void sign_message() {
    if (!keys_generated) {
        printf("\n❌ Error: Keys not generated yet! Please select option 1 first.\n");
        return;
    }

    char message[MAX_MSG_LEN];
    uint8_t hash[32];

    printf("\n--- Sign Message with Alice's Private Key ---\n");
    printf("Enter message to sign: ");
    int len = read_line(message, sizeof(message));
    if (len <= 0) {
        printf("❌ Invalid input\n");
        return;
    }

    // Hash with SHA3-256
    sha3_context ctx;
    sha3_Init256(&ctx);
    sha3_Update(&ctx, (const uint8_t *)message, len);
    const uint8_t *sha3_hash = sha3_Finalize(&ctx);
    memcpy(hash, sha3_hash, 32);

    // Sign the hash
    if (!uECC_sign(alice_priv, hash, 32, last_signature, curve)) {
        printf("\n❌ Signing failed!\n");
        return;
    }

    // Store message globally
    memcpy(last_message, message, len);
    last_message[len] = '\0';
    last_msg_len = len;

    printf("\nMessage: %s\n", message);
    print_hex("SHA3-256 Hash", hash, 32);
    print_hex("Alice's Signature", last_signature, 64);
    printf("\n✅ Message signed successfully!\n");
}

// ---------- Helper to read hex signature ----------
int read_hex(const char *prompt, uint8_t *buffer, size_t max_len) {
    char input[MAX_INPUT_SIZE];
    printf("%s (hex): ", prompt);
    int len = read_line(input, sizeof(input));
    if (len <= 0) return 0;

    char *p = input;
    size_t byte_idx = 0;
    while (*p && byte_idx < max_len) {
        while (*p == ' ') p++;
        if (!*p) break;
        char hex_byte[3] = {0};
        hex_byte[0] = *p++;
        if (*p) hex_byte[1] = *p++;
        buffer[byte_idx++] = (uint8_t)strtoul(hex_byte, NULL, 16);
    }
    return (int)byte_idx;
}

// ---------- Verify a signature ----------
void verify_signature() {
    if (!keys_generated) {
        printf("\n❌ Error: Keys not generated yet! Please select option 1 first.\n");
        return;
    }

    if (last_msg_len == 0) {
        printf("\n❌ No message has been signed yet! Please select option 3 first.\n");
        return;
    }

    char choice[4];
    printf("\n--- Verify Signature with Alice's Public Key ---\n");
    printf("Do you want to verify the last signed message? (y/n): ");
    int ch_len = read_line(choice, sizeof(choice));
    if (ch_len <= 0) return;

    char message[MAX_MSG_LEN];
    uint8_t signature[64];

    if (choice[0] == 'y' || choice[0] == 'Y') {
        memcpy(message, last_message, last_msg_len);
        memcpy(signature, last_signature, 64);
    } else {
        printf("Enter message to verify: ");
        int msg_len = read_line(message, sizeof(message));
        if (msg_len <= 0) {
            printf("❌ Invalid input\n");
            return;
        }

        printf("Enter signature (128 hex chars): ");
        char sig_input[129] = {0};
        int sig_len = read_line(sig_input, sizeof(sig_input));
        if (sig_len != 128) {
            printf("❌ Invalid signature length! Must be 128 hex chars.\n");
            return;
        }

        for (int i = 0; i < 64; i++) {
            sscanf(&sig_input[i * 2], "%2hhx", &signature[i]);
        }
    }

    // Hash the message (use actual message length)
    int msg_len = (choice[0] == 'y' || choice[0] == 'Y') ? last_msg_len : (int)strlen(message);
    uint8_t hash[32];
    sha3_context ctx;
    sha3_Init256(&ctx);
    sha3_Update(&ctx, (const uint8_t *)message, msg_len);
    const uint8_t *sha3_hash = sha3_Finalize(&ctx);
    memcpy(hash, sha3_hash, 32);

    if (uECC_verify(alice_pub, hash, 32, signature, curve)) {
        printf("\n✅ Signature verification PASSED!\n");
        printf("Message is authentic and from Alice.\n");
    } else {
        printf("\n❌ Signature verification FAILED!\n");
    }
}

// ---------- View keys ----------
void view_keys() {
    if (!keys_generated) {
        printf("\n❌ No keys generated yet! Please select option 1 first.\n");
        return;
    }

    printf("\n--- Current Key Information ---\n");
    printf("\nAlice's Keys:\n");
    print_hex("  Private Key", alice_priv, 32);
    print_hex("  Public Key ", alice_pub, 64);

    printf("\nBob's Keys:\n");
    print_hex("  Private Key", bob_priv, 32);
    print_hex("  Public Key ", bob_pub, 64);
}

// ---------- Main interactive loop ----------
void ecc_sha3_demo() {
    char choice_buffer[10];
    int choice;

    read_line(choice_buffer, sizeof(choice_buffer));
    choice = atoi(choice_buffer);

    while (1) {
        display_menu();

        if (read_line(choice_buffer, sizeof(choice_buffer)) <= 0) {
            continue;
        }

        choice = atoi(choice_buffer);

        switch (choice) {
            case 1: generate_keys(); break;
            case 2: compute_shared_secret(); break;
            case 3: sign_message(); break;
            case 4: verify_signature(); break;
            case 5: view_keys(); break;
            case 6: pico_restart(); break;
            default:
                printf("\n❌ Invalid choice. Please select 1-6.\n");
                break;
        }

        sleep_ms(100);
    }
}

// ---------- Entry point ----------
int main() {
    stdio_init_all();          // initialise USB serial
    printf("\nStarting Pico 2 ECC + SHA3 Interactive Demo...\n");
    sleep_ms(2000);            // let USB settle

    ecc_sha3_demo();           // never returns
    return 0;
}