// uECC_config.h
#ifndef UECC_CONFIG_H
#define UECC_CONFIG_H

#define uECC_WORD_SIZE 4
#define uECC_PLATFORM uECC_arm_thumb2
#define uECC_OPTIMIZATION_LEVEL 1
#define uECC_SUPPORTS_secp256r1 1

#endif