#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "pico/stdlib.h"
#include "pico/rand.h"

#include "api.h"
#include "core.h"
#include "ascon.h"

#define MAX_INPUT_SIZE 256
#define ASCON_HASH_SIZE 32

/* =========================================================
   External Function Prototypes
   ========================================================= */

extern int crypto_aead_encrypt(
    unsigned char *c,
    unsigned long long *clen,
    const unsigned char *m,
    unsigned long long mlen,
    const unsigned char *ad,
    unsigned long long adlen,
    const unsigned char *nsec,
    const unsigned char *npub,
    const unsigned char *k);

extern int crypto_aead_decrypt(
    unsigned char *m,
    unsigned long long *mlen,
    unsigned char *nsec,
    const unsigned char *c,
    unsigned long long clen,
    const unsigned char *ad,
    unsigned long long adlen,
    const unsigned char *npub,
    const unsigned char *k);

extern int crypto_hash(
    unsigned char *out,
    const unsigned char *in,
    unsigned long long inlen);

/* =========================================================
   Print Bytes in Hex
   ========================================================= */

void print_hex(const char *label,
               const unsigned char *data,
               size_t len)
{
    printf("%s: ", label);

    for (size_t i = 0; i < len; i++)
    {
        printf("%02x", data[i]);
    }

    printf("\n");
}

/* =========================================================
   Generate Random Bytes
   ========================================================= */

void generate_random_bytes(uint8_t *buf,
                           size_t len)
{
    for (size_t i = 0; i < len; i++)
    {
        buf[i] = (uint8_t)(get_rand_32() & 0xFF);
    }
}

/* =========================================================
   Read Line from USB Serial
   ========================================================= */

int pico_read_line(char *buffer,
                   size_t max_len)
{
    int len = 0;

    while (len < (max_len - 1))
    {
        int c = getchar_timeout_us(0);

        if (c == PICO_ERROR_TIMEOUT)
        {
            sleep_ms(10);
            continue;
        }

        if (c == '\r' || c == '\n')
        {
            buffer[len] = '\0';
            printf("\n");
            return len;
        }

        /* Backspace handling */

        if (c == 8 || c == 127)
        {
            if (len > 0)
            {
                len--;

                printf("\b \b");
                fflush(stdout);
            }

            continue;
        }

        buffer[len++] = (char)c;

        putchar(c);

        fflush(stdout);
    }

    buffer[len] = '\0';

    return len;
}

/* =========================================================
   Interactive ASCON Demo
   ========================================================= */

void ascon_aead_demo_interactive(void)
{
    unsigned char key[CRYPTO_KEYBYTES];

    unsigned char nonce[CRYPTO_NPUBBYTES];

    const unsigned char ad[] = "Associated Data";

    unsigned char ciphertext[MAX_INPUT_SIZE + CRYPTO_ABYTES];

    unsigned char decrypted[MAX_INPUT_SIZE + 1];

    unsigned long long clen = 0;
    unsigned long long mlen = 0;

    char plaintext[MAX_INPUT_SIZE];

    size_t input_len = 0;

    int choice;

    char choice_buf[10];

    pico_read_line(choice_buf,
                       sizeof(choice_buf));

    printf("\nASCON Interactive Demo Started\n");

    while (1)
    {
        printf("\n=== ASCON AEAD Demo ===\n");
        printf("1. Encrypt message\n");
        printf("2. Decrypt last message\n");
        printf("3. Hash the message\n");
        printf("4. Exit\n");
        printf("Select option (1-4): ");

        fflush(stdout);

        pico_read_line(choice_buf,
                       sizeof(choice_buf));

        choice = atoi(choice_buf);

        switch (choice)
        {
            /* ================================================= */
            case 1:
            {
                printf("\nEnter plaintext message: ");

                fflush(stdout);

                input_len =
                    pico_read_line(plaintext,
                                   sizeof(plaintext));

                if (input_len <= 0)
                {
                    printf("Empty input. Try again.\n");
                    break;
                }

                /* Generate random key and nonce */

                generate_random_bytes(key,
                                      CRYPTO_KEYBYTES);

                generate_random_bytes(nonce,
                                      CRYPTO_NPUBBYTES);

                printf("\nPlaintext: %s\n",
                       plaintext);

                print_hex("Key",
                          key,
                          CRYPTO_KEYBYTES);

                print_hex("Nonce",
                          nonce,
                          CRYPTO_NPUBBYTES);

                print_hex("Associated Data",
                          ad,
                          sizeof(ad) - 1);

                /* Encrypt */

                if (crypto_aead_encrypt(
                        ciphertext,
                        &clen,
                        (unsigned char *)plaintext,
                        input_len,
                        ad,
                        sizeof(ad) - 1,
                        NULL,
                        nonce,
                        key) == 0)
                {
                    print_hex("Ciphertext",
                              ciphertext,
                              input_len);

                    print_hex("Authentication Tag",
                              ciphertext + input_len,
                              CRYPTO_ABYTES);

                    printf("Encryption completed successfully\n");
                }
                else
                {
                    printf("Encryption failed!\n");
                }

                break;
            }

            /* ================================================= */
            case 2:
            {
                if (clen == 0)
                {
                    printf("No ciphertext to decrypt. Encrypt first.\n");
                    break;
                }

                printf("\nAttempting to decrypt last ciphertext...\n");

                print_hex("Nonce",
                          nonce,
                          CRYPTO_NPUBBYTES);

                print_hex("Associated Data",
                          ad,
                          sizeof(ad) - 1);

                print_hex("Ciphertext",
                          ciphertext,
                          clen - CRYPTO_ABYTES);

                print_hex("Authentication Tag",
                          ciphertext + (clen - CRYPTO_ABYTES),
                          CRYPTO_ABYTES);

                if (crypto_aead_decrypt(
                        decrypted,
                        &mlen,
                        NULL,
                        ciphertext,
                        clen,
                        ad,
                        sizeof(ad) - 1,
                        nonce,
                        key) == 0)
                {
                    decrypted[mlen] = '\0';

                    printf("Decryption successful!\n");

                    printf("Decrypted text: %s\n",
                           (char *)decrypted);
                }
                else
                {
                    printf("Authentication failed! Tag mismatch.\n");
                }

                break;
            }

            /* ================================================= */
            case 3:
            {
                printf("\n=== Testing Hash ===\n");

                unsigned char message[128];

                unsigned char hash[ASCON_HASH_SIZE];

                printf("Enter message to hash: ");

                fflush(stdout);

                pico_read_line((char *)message,
                               sizeof(message));

                unsigned long long hash_len =
                    strlen((char *)message);

                printf("\nHashing...\n");

                int result =
                    crypto_hash(hash,
                                message,
                                hash_len);

                if (result == 0)
                {
                    print_hex("Hash",
                              hash,
                              ASCON_HASH_SIZE);

                    printf("Hashing successful!\n");
                }
                else
                {
                    printf("Hashing failed!\n");
                }

                break;
            }

            /* ================================================= */
            case 4:
            {
                printf("Exiting demo...\n");
                return;
            }

            /* ================================================= */
            default:
            {
                printf("Invalid choice. Try again.\n");
                break;
            }
        }

        sleep_ms(500);
    }
}

/* =========================================================
   MAIN
   ========================================================= */

int main()
{
    stdio_init_all();

    /* Wait for USB CDC serial monitor */

    sleep_ms(5000);

    printf("\n=== ASCON AEAD Interactive Demonstration ===\n");

    printf("ASCON Version: %s\n",
           CRYPTO_VERSION);

    printf("Key size: %d bytes\n",
           CRYPTO_KEYBYTES);

    printf("Nonce size: %d bytes\n",
           CRYPTO_NPUBBYTES);

    printf("Tag size: %d bytes\n",
           CRYPTO_ABYTES);

    printf("Enter messages via USB serial\n");

    fflush(stdout);

    ascon_aead_demo_interactive();

    while (1)
    {
        tight_loop_contents();
    }

    return 0;
}