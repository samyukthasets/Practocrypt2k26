#ifndef CONFIG_H
#define CONFIG_H

// Configuration for ASCON Hash
#define ASCON_HASH_BYTES 32
#define ASCON_HASH_ROUNDS 12
#define ASCON_HASH_RATE 8

// Define which variant to use
#if ASCON_HASH_BYTES == 32 && ASCON_HASH_ROUNDS == 12
#define IV(i) ASCON_HASH_IV##i
#define PB_START_ROUND 0xf0
#elif ASCON_HASH_BYTES == 32 && ASCON_HASH_ROUNDS == 8
#define IV(i) ASCON_HASHA_IV##i
#define PB_START_ROUND 0xb4
#elif ASCON_HASH_BYTES == 0 && ASCON_HASH_ROUNDS == 12
#define IV(i) ASCON_XOF_IV##i
#define PB_START_ROUND 0xf0
#elif ASCON_HASH_BYTES == 0 && ASCON_HASH_ROUNDS == 8
#define IV(i) ASCON_XOFA_IV##i
#define PB_START_ROUND 0xb4
#endif

#define PA_START_ROUND 0xf0

#endif