from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from binascii import hexlify, unhexlify

# ========== ENCRYPTION ==========
def chacha20poly_encrypt(key_hex, nonce_hex, ad_hex, plaintext_str):
    key = unhexlify(key_hex)
    nonce = unhexlify(nonce_hex)
    ad = unhexlify(ad_hex) if ad_hex else b""
    plaintext = plaintext_str.encode()

    aead = ChaCha20Poly1305(key)
    ciphertext_with_tag = aead.encrypt(nonce, plaintext, ad)

    # Split ciphertext and tag (last 16 bytes are tag)
    ciphertext = ciphertext_with_tag[:-16]
    tag = ciphertext_with_tag[-16:]

    return ciphertext, tag


# ========== DECRYPTION ==========
def chacha20poly_decrypt(key_hex, nonce_hex, ad_hex, ciphertext_hex, tag_hex):
    key = unhexlify(key_hex)
    nonce = unhexlify(nonce_hex)
    ad = unhexlify(ad_hex) if ad_hex else b""
    ciphertext = unhexlify(ciphertext_hex)
    tag = unhexlify(tag_hex)

    aead = ChaCha20Poly1305(key)
    try:
        plaintext = aead.decrypt(nonce, ciphertext + tag, ad)
        return True, plaintext
    except Exception:
        return False, None


# ========== DEMO ==========
if __name__ == "__main__":
    # Example test vectors (replace with your values)
    key_hex   = "2dcf462904b478d868a7ff3f2bf1fcd97a96092ca5577464c4af1528a4e957db"
    nonce_hex = "5e20fb38a84ea61493255624"
    ad_hex    = "4173736f6369617465642044617461"  # "Associated Data"
    plaintext = "devi"

    print("=== ChaCha20-Poly1305 Encryption ===")
    ciphertext, tag = chacha20poly_encrypt(key_hex, nonce_hex, ad_hex, plaintext)
    print("Plaintext:", plaintext)
    print("Ciphertext:", hexlify(ciphertext).decode())
    print("Tag:", hexlify(tag).decode())

    print("\n=== ChaCha20-Poly1305 Decryption ===")
    ok, recovered = chacha20poly_decrypt(
        key_hex,
        nonce_hex,
        ad_hex,
        hexlify(ciphertext).decode(),
        hexlify(tag).decode()
    )

    print("Authentication OK:", ok)
    if ok:
        print("Recovered plaintext:", recovered.decode())



