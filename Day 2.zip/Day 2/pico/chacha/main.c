#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "pico/stdlib.h"
#include "chachapoly.h"
#include "chacha.h"

#define MAX_INPUT_SIZE 256

/* =========================================================
 * Print bytes in hex
 * ========================================================= */
void print_hex(const char *label,
               const unsigned char *data,
               size_t len)
{
    printf("%s: ", label);

    for (size_t i = 0; i < len; i++)
    {
        printf("%02x", data[i]);
    }

    printf("\n");
}

/* =========================================================
 * Generate random bytes
 * ========================================================= */
void generate_random_data(uint8_t *buf,
                          size_t len)
{
    for (size_t i = 0; i < len; i++)
    {
        buf[i] = rand() % 256;
    }
}

/* =========================================================
 * Safe UART line input
 * ========================================================= */
int pico_read_line(char *buffer,
                   size_t max_len)
{
    int len = 0;
    int c;

    while (len < (max_len - 1))
    {
        c = getchar_timeout_us(0);

        if (c == PICO_ERROR_TIMEOUT)
        {
            sleep_ms(10);
            continue;
        }

        if (c == '\r' || c == '\n')
        {
            buffer[len] = '\0';
            printf("\n");
            return len;
        }

        /* Backspace */
        if (c == 127 || c == 8)
        {
            if (len > 0)
            {
                len--;
                printf("\b \b");
            }

            continue;
        }

        buffer[len++] = (char)c;

        putchar(c);
    }

    buffer[len] = '\0';

    return len;
}

/* =========================================================
 * Interactive Demo
 * ========================================================= */
void chachapoly_demo(void)
{
    struct chachapoly_ctx ctx;

    unsigned char key[32];
    unsigned char nonce[12];

    const unsigned char ad[] = "Associated Data";

    unsigned char plaintext[MAX_INPUT_SIZE];
    unsigned char ciphertext[MAX_INPUT_SIZE];
    unsigned char decrypted[MAX_INPUT_SIZE];

    unsigned char tag[16];

    int choice;
    int input_len = 0;

    char choice_buf[10];

    pico_read_line(choice_buf,
                       sizeof(choice_buf));

    while (1)
    {
        printf("\n");
        printf("=== ChaCha20-Poly1305 Demo ===\n");
        printf("1. Encrypt message\n");
        printf("2. Decrypt last message\n");
        printf("3. Exit\n");
        printf("Select option (1-3): ");

        pico_read_line(choice_buf,
                       sizeof(choice_buf));

        choice = atoi(choice_buf);

        switch (choice)
        {
            /* ========================================= */
            case 1:
            {
                printf("\nEnter plaintext message: ");

                input_len =
                    pico_read_line((char *)plaintext,
                                   sizeof(plaintext));

                if (input_len <= 0)
                {
                    printf("Empty input\n");
                    break;
                }

                /* Generate random key + nonce */
                generate_random_data(key,
                                     sizeof(key));

                generate_random_data(nonce,
                                     sizeof(nonce));

                printf("\nPlaintext: %s\n",
                       plaintext);

                print_hex("Key",
                          key,
                          sizeof(key));

                print_hex("Nonce",
                          nonce,
                          sizeof(nonce));

                print_hex("Associated Data",
                          ad,
                          sizeof(ad) - 1);

                /* Init */
                chachapoly_init(&ctx,
                                key,
                                256);

                /* Encrypt */
                chachapoly_crypt(&ctx,
                                 nonce,
                                 ad,
                                 sizeof(ad) - 1,
                                 plaintext,
                                 input_len,
                                 ciphertext,
                                 tag,
                                 sizeof(tag),
                                 1);

                print_hex("Ciphertext",
                          ciphertext,
                          input_len);

                print_hex("Authentication Tag",
                          tag,
                          sizeof(tag));

                printf("Encryption successful\n");

                break;
            }

            /* ========================================= */
            case 2:
            {
                if (input_len <= 0)
                {
                    printf("No ciphertext available\n");
                    break;
                }

                printf("\nDecrypting...\n");

                print_hex("Nonce",
                          nonce,
                          sizeof(nonce));

                print_hex("Associated Data",
                          ad,
                          sizeof(ad) - 1);

                print_hex("Ciphertext",
                          ciphertext,
                          input_len);

                print_hex("Authentication Tag",
                          tag,
                          sizeof(tag));

                /* Init again */
                chachapoly_init(&ctx,
                                key,
                                256);

                int ret =
                    chachapoly_crypt(&ctx,
                                     nonce,
                                     ad,
                                     sizeof(ad) - 1,
                                     ciphertext,
                                     input_len,
                                     decrypted,
                                     tag,
                                     sizeof(tag),
                                     0);

                if (ret == CHACHAPOLY_OK)
                {
                    decrypted[input_len] = '\0';

                    printf("Decryption successful\n");

                    printf("Decrypted text: %s\n",
                           decrypted);
                }
                else
                {
                    printf("Authentication failed\n");
                }

                break;
            }

            /* ========================================= */
            case 3:
            {
                printf("Exit\n");
                return;
            }

            /* ========================================= */
            default:
            {
                printf("Invalid option\n");
                break;
            }
        }

        sleep_ms(500);
    }
}

/* =========================================================
 * Main
 * ========================================================= */
int main()
{
    stdio_init_all();

    sleep_ms(2000);

    printf("\n");
    printf("=====================================\n");
    printf(" Pico ChaCha20-Poly1305 Demo\n");
    printf("=====================================\n");

    chachapoly_demo();

    return 0;
}