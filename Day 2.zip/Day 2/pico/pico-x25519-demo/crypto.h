#ifndef _CRYPTO_H_
#define _CRYPTO_H_

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

// Endian macros (assume little-endian for ESP32)
#define U8TO32_LITTLE(p) \
  (((uint32_t)((p)[0])      ) | \
   ((uint32_t)((p)[1]) <<  8) | \
   ((uint32_t)((p)[2]) << 16) | \
   ((uint32_t)((p)[3]) << 24))

#define U32TO8_LITTLE(p, v) \
  do { \
    (p)[0] = (uint8_t)((v)      ); \
    (p)[1] = (uint8_t)((v) >>  8); \
    (p)[2] = (uint8_t)((v) >> 16); \
    (p)[3] = (uint8_t)((v) >> 24); \
  } while (0)

void crypto_zero(void *dest, size_t len);
bool crypto_equal(const void *a, const void *b, size_t size);

#endif