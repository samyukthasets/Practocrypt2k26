/*
 * X25519 interactive demo for Raspberry Pi Pico 2 (RP2350)
 * Uses Pico SDK and a generic X25519 library.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Pico SDK headers
#include "pico/stdlib.h"
#include "pico/rand.h"
#include "pico/time.h"          // for time_us_64()
#include "hardware/watchdog.h"

// X25519 library (must be provided)
#include "x25519.h"

#define MAX_INPUT 32

static uint8_t alice_private[32], alice_public[32];
static uint8_t bob_private[32], bob_public[32];
static uint8_t shared_alice[32], shared_bob[32];
static int keys_generated = 0;

// ---------- Pico random generator (using TRNG) ----------
void pico_fill_random(void *buf, size_t len) {
    uint8_t *bytes = (uint8_t *)buf;
    size_t remaining = len;
    while (remaining >= 4) {
        uint32_t rnd = get_rand_32();
        *bytes++ = (rnd >> 0) & 0xFF;
        *bytes++ = (rnd >> 8) & 0xFF;
        *bytes++ = (rnd >> 16) & 0xFF;
        *bytes++ = (rnd >> 24) & 0xFF;
        remaining -= 4;
    }
    if (remaining > 0) {
        uint32_t rnd = get_rand_32();
        for (size_t i = 0; i < remaining; i++) {
            bytes[i] = (rnd >> (i * 8)) & 0xFF;
        }
    }
}

// ---------- Restart via watchdog ----------
void pico_restart(void) {
    printf("\nRestarting...\n");
    fflush(stdout);
    sleep_ms(1000);
    watchdog_enable(1, 1);   // enable watchdog with 1 ms timeout
    while (1);               // wait for reset
}

// ---------- Generate a valid X25519 private key (with clamping) ----------
void generate_random_private_key(uint8_t private_key[32]) {
    pico_fill_random(private_key, 32);
    // Clamp the key as per RFC 7748
    private_key[0] &= 0xF8;
    private_key[31] = (private_key[31] & 0x7F) | 0x40;
}

// ---------- Helper: print hex ----------
void print_hex(const char *label, const uint8_t *data, size_t len) {
    printf("%s: ", label);
    for (size_t i = 0; i < len; i++) {
        printf("%02x", data[i]);
    }
    printf("\n");
}

// ---------- Read a line from stdin (USB serial) ----------
int read_line(char *buffer, int max_len) {
    int len = 0;
    int ch;
    while (len < max_len - 1) {
        ch = getchar_timeout_us(100000); // 100 ms timeout
        if (ch == PICO_ERROR_TIMEOUT) continue;
        if (ch == '\r' || ch == '\n') {
            if (len > 0) break;
            continue;
        }
        if (ch == '\b' || ch == 127) {
            if (len > 0) {
                len--;
                printf("\b \b");
                fflush(stdout);
            }
            continue;
        }
        buffer[len++] = (char)ch;
        printf("%c", ch);
        fflush(stdout);
    }
    buffer[len] = '\0';
    printf("\n");
    return len;
}

// ---------- Interactive Functions ----------
void generate_keys() {
    printf("\n--- Generating X25519 Keys ---\n");
    generate_random_private_key(alice_private);
    generate_random_private_key(bob_private);
    x25519_base(alice_public, alice_private, 1);
    x25519_base(bob_public, bob_private, 1);

    print_hex("Alice Private", alice_private, 32);
    print_hex("Alice Public", alice_public, 32);
    print_hex("Bob Private", bob_private, 32);
    print_hex("Bob Public", bob_public, 32);

    keys_generated = 1;
    printf("\n✅ Key generation complete!\n");
}

void compute_shared_secret() {
    if (!keys_generated) {
        printf("\n❌ Keys not generated yet. Please generate keys first.\n");
        return;
    }

    x25519(shared_alice, alice_private, bob_public, 1);
    x25519(shared_bob, bob_private, alice_public, 1);

    print_hex("Shared Secret (Alice)", shared_alice, 32);
    print_hex("Shared Secret (Bob)  ", shared_bob, 32);

    if (memcmp(shared_alice, shared_bob, 32) == 0) {
        printf("\n✅ Shared secret matches!\n");
    } else {
        printf("\n❌ Shared secret mismatch!\n");
    }
}

void run_deterministic_test() {
    printf("\n--- Deterministic Test (RFC 7748) ---\n");

    // Fixed test vectors from RFC 7748
    uint8_t alice_priv[32] = {
        0x77,0x07,0x6d,0x0a,0x73,0x18,0xa5,0x7d,
        0x3c,0x16,0xc1,0x72,0x51,0xb2,0x66,0x45,
        0xdf,0x4c,0x2f,0x87,0xeb,0xc0,0x99,0x2a,
        0xb1,0x77,0xfb,0xa5,0x1d,0xb9,0x2c,0x2a
    };
    uint8_t bob_priv[32] = {
        0x5d,0xab,0x08,0x7e,0x62,0x4a,0x8a,0x4b,
        0x79,0xe1,0x7f,0x8b,0x83,0x80,0x0e,0xe6,
        0x6f,0x3b,0xb1,0x29,0x26,0x18,0xb6,0xfd,
        0x1c,0x2f,0x8b,0x27,0xff,0x88,0xe0,0xeb
    };
    uint8_t expected[32] = {
        0x4a,0x5d,0x9d,0x5b,0xa4,0xce,0x2d,0xe1,
        0x72,0x8e,0x3b,0xf4,0x80,0x35,0x0f,0x25,
        0xe0,0x7e,0x21,0xc9,0x47,0xd1,0x9e,0x33,
        0x76,0xf0,0x9b,0x3c,0x1e,0x16,0x17,0x42
    };

    uint8_t alice_pub[32], bob_pub[32], sa[32], sb[32];
    x25519_base(alice_pub, alice_priv, 1);
    x25519_base(bob_pub, bob_priv, 1);
    x25519(sa, alice_priv, bob_pub, 1);
    x25519(sb, bob_priv, alice_pub, 1);

    print_hex("Expected Shared", expected, 32);
    print_hex("Computed Shared", sa, 32);

    if (memcmp(sa, expected, 32) == 0 && memcmp(sa, sb, 32) == 0)
        printf("✅ Deterministic test PASSED\n");
    else
        printf("❌ Deterministic test FAILED\n");
}

void run_performance_test(int iterations) {
    printf("\n--- Performance Test (%d iterations) ---\n", iterations);
    int success = 0;
    uint64_t start = time_us_64();

    for (int i = 0; i < iterations; i++) {
        uint8_t priv1[32], priv2[32], pub1[32], pub2[32], ss1[32], ss2[32];
        generate_random_private_key(priv1);
        generate_random_private_key(priv2);
        x25519_base(pub1, priv1, 1);
        x25519_base(pub2, priv2, 1);
        x25519(ss1, priv1, pub2, 1);
        x25519(ss2, priv2, pub1, 1);
        if (memcmp(ss1, ss2, 32) == 0) success++;
    }

    uint64_t end = time_us_64();
    double total_ms = (end - start) / 1000.0;
    double avg_ms = total_ms / iterations;

    printf("Success rate: %d/%d (%.1f%%)\n", success, iterations, (success*100.0)/iterations);
    printf("Total time: %.2f ms, Avg time: %.2f ms\n", total_ms, avg_ms);
    printf("Ops per second: %.1f\n", 1000.0/avg_ms);
}

// ---------- Menu ----------
void display_menu() {
    printf("\n=====================================\n");
    printf("Pico 2 X25519 Interactive Demo\n");
    printf("=====================================\n");
    printf("1. Generate Alice & Bob Keys\n");
    printf("2. Compute Shared Secret\n");
    printf("3. Run Deterministic Test (RFC 7748)\n");
    printf("4. Run Performance Test\n");
    printf("5. View Current Keys\n");
    printf("6. Exit (Restart)\n");
    printf("Enter choice: ");
}

void view_keys() {
    if (!keys_generated) {
        printf("\n❌ Keys not generated yet.\n");
        return;
    }
    print_hex("Alice Private", alice_private, 32);
    print_hex("Alice Public", alice_public, 32);
    print_hex("Bob Private", bob_private, 32);
    print_hex("Bob Public", bob_public, 32);
}

// ---------- Main interactive loop ----------
void x25519_demo() {
    char input[MAX_INPUT];
    int choice;
    read_line(input, sizeof(input));
    choice = atoi(input);

    while (1) {
        display_menu();
        if (read_line(input, sizeof(input)) <= 0) continue;
        choice = atoi(input);

        switch (choice) {
            case 1: generate_keys(); break;
            case 2: compute_shared_secret(); break;
            case 3: run_deterministic_test(); break;
            case 4: run_performance_test(10); break;
            case 5: view_keys(); break;
            case 6: pico_restart(); break;
            default:
                printf("❌ Invalid choice, select 1-6.\n");
                break;
        }
        sleep_ms(100);
    }
}

// ---------- Entry point ----------
int main() {
    stdio_init_all();          // initialise USB serial
    printf("\n========== Pico 2 X25519 Demo ==========\n");
    sleep_ms(2000);            // let USB settle

    x25519_demo();             // never returns
    return 0;
}