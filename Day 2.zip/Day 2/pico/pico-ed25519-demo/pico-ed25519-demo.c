/*
 * Ed25519 demo for Raspberry Pi Pico 2 (RP2350)
 * Key Generation + Sign + Verify 
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Pico SDK headers
#include "pico/stdlib.h"
#include "pico/rand.h"
#include "hardware/watchdog.h"

// Ed25519 implementation
#include "src/ed25519.h"
#include "src/ge.h"
#include "src/sc.h"

#define MAX_MSG_LEN 256
#define MAX_INPUT_SIZE 128

// Global Ed25519 keys
unsigned char alice_pub[32], alice_priv[64];
unsigned char bob_pub[32], bob_priv[64];
unsigned char last_signature[64];
char last_message[MAX_MSG_LEN];
int last_msg_len = 0;
int keys_generated = 0;
unsigned char p1[32], p2[32];

// ---------- Pico random generator ----------
void pico_fill_random(void *buf, size_t len)
{
    uint8_t *bytes = (uint8_t *)buf;
    size_t remaining = len;

    while (remaining >= 4)
    {
        uint32_t rnd = get_rand_32();

        bytes[0] = (rnd >> 0) & 0xFF;
        bytes[1] = (rnd >> 8) & 0xFF;
        bytes[2] = (rnd >> 16) & 0xFF;
        bytes[3] = (rnd >> 24) & 0xFF;

        bytes += 4;
        remaining -= 4;
    }

    if (remaining > 0)
    {
        uint32_t rnd = get_rand_32();

        for (size_t i = 0; i < remaining; i++)
        {
            bytes[i] = (rnd >> (i * 8)) & 0xFF;
        }
    }
}

// ---------- Pico restart ----------
void pico_restart(void)
{
    printf("\nRestarting...\n");
    fflush(stdout);

    sleep_ms(1000);

    watchdog_enable(1, 1);

    while (1)
        ;
}

// ---------- Print hex ----------
void print_hex(const char *label, const unsigned char *data, size_t len)
{
    printf("%s: ", label);

    for (size_t i = 0; i < len; i++)
    {
        printf("%02X", data[i]);
    }

    printf("\n");
}

// ---------- Read line ----------
int read_line(char *buffer, int max_len)
{
    int len = 0;
    int ch;

    while (len < max_len - 1)
    {
        ch = getchar_timeout_us(100000);

        if (ch == PICO_ERROR_TIMEOUT)
            continue;

        if (ch == '\r' || ch == '\n')
        {
            if (len > 0)
                break;
            continue;
        }

        if (ch == '\b' || ch == 127)
        {
            if (len > 0)
            {
                len--;
                printf("\b \b");
                fflush(stdout);
            }
            continue;
        }

        buffer[len++] = (char)ch;
        printf("%c", ch);
        fflush(stdout);
    }

    buffer[len] = '\0';
    printf("\n");

    return len;
}

// ---------- Menu ----------
void display_menu()
{
    printf("\n===========================================\n");
    printf("      Pico 2 Ed25519 Demo\n");
    printf("===========================================\n");
    printf("1. Generate Alice & Bob Keys\n");
    printf("2. Sign a Message with Alice's Private Key\n");
    printf("3. Verify Signature with Alice's Public Key\n");
    printf("4. View Keys\n");
    printf("5. Exit (Restart)\n");
    printf("Enter choice: ");
}

// ---------- Generate key pairs ----------
void generate_keys()
{
    unsigned char seed[32];

    printf("\n--- Generating Ed25519 Key Pairs ---\n");

    // Alice
    pico_fill_random(seed, 32);
    ed25519_create_keypair(alice_pub, alice_priv, seed);

    printf("\n✅ Alice's Keys Generated\n");
    print_hex("Alice Private Key (seed)", seed, 32);
    print_hex("Alice Public Key", alice_pub, 32);

    memcpy(p1, seed, 32);

    // Bob
    pico_fill_random(seed, 32);
    ed25519_create_keypair(bob_pub, bob_priv, seed);

    printf("\n✅ Bob's Keys Generated\n");
    print_hex("Bob Private Key (seed)", seed, 32);
    print_hex("Bob Public Key", bob_pub, 32);

    memcpy(p2, seed, 32);

    keys_generated = 1;
}

// ---------- Sign message ----------
void sign_message()
{
    if (!keys_generated)
    {
        printf("\n❌ Keys not generated yet! Please select option 1.\n");
        return;
    }

    char message[MAX_MSG_LEN];

    printf("\nEnter message to sign: ");

    int len = read_line(message, MAX_MSG_LEN);

    if (len <= 0)
        return;

    ed25519_sign(
        last_signature,
        (unsigned char *)message,
        len,
        alice_pub,
        alice_priv);

    memcpy(last_message, message, len);

    last_msg_len = len;
    last_message[len] = '\0';

    printf("\n✅ Message signed successfully!\n");

    print_hex("Message", (unsigned char *)message, len);
    print_hex("Signature", last_signature, 64);
}

// ---------- Verify signature ----------
void verify_signature()
{
    if (!keys_generated)
    {
        printf("\n❌ Keys not generated yet! Please select option 1.\n");
        return;
    }

    if (last_msg_len == 0)
    {
        printf("\n❌ No message signed yet! Please select option 2.\n");
        return;
    }

    char choice[4];

    printf("\nVerify last signed message? (y/n): ");

    if (read_line(choice, sizeof(choice)) <= 0)
        return;

    if (choice[0] == 'y' || choice[0] == 'Y')
    {
        if (ed25519_verify(
                last_signature,
                (unsigned char *)last_message,
                last_msg_len,
                alice_pub))
        {
            printf("\n✅ Signature verification PASSED!\n");
        }
        else
        {
            printf("\n❌ Signature verification FAILED!\n");
        }
    }
}

// ---------- View keys ----------
void view_keys()
{
    if (!keys_generated)
    {
        printf("\n❌ Keys not generated yet! Please select option 1.\n");
        return;
    }

    printf("\n--- Current Key Information ---\n");

    print_hex("Alice Private Key (seed)", p1, 32);
    print_hex("Alice Public Key", alice_pub, 32);

    print_hex("Bob Private Key (seed)", p2, 32);
    print_hex("Bob Public Key", bob_pub, 32);
}

// ---------- Main demo loop ----------
void ed25519_demo()
{
    char choice_buffer[10];
    int choice;
    read_line(choice_buffer, sizeof(choice_buffer));
        choice = atoi(choice_buffer);

    while (1)
    {
        display_menu();

        if (read_line(choice_buffer, sizeof(choice_buffer)) <= 0)
            continue;

        choice = atoi(choice_buffer);

        switch (choice)
        {
        case 1:
            generate_keys();
            break;

        case 2:
            sign_message();
            break;

        case 3:
            verify_signature();
            break;

        case 4:
            view_keys();
            break;

        case 5:
            pico_restart();
            break;

        default:
            printf("\n❌ Invalid choice. Please select 1-5.\n");
            break;
        }

        sleep_ms(100);
    }
}

// ---------- Entry point ----------
int main()
{
    stdio_init_all();

    printf("\nStarting Pico 2 Ed25519 Interactive Demo...\n");

    sleep_ms(2000);

    ed25519_demo();

    return 0;
}