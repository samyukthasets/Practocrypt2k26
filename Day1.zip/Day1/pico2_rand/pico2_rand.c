#include <stdio.h>
#include "pico/stdlib.h"
#include "pico/rand.h"          // Correct header for RNG (TRNG on RP2350)

#define CHUNK_SIZE  64
#define DELAY_MS    1

int main() {
    stdio_init_all();

    while (1) {
        for (int i = 0; i < CHUNK_SIZE; i++) {
            uint32_t rnd = get_rand_32();   // Hardware-accelerated random number
            for (int b = 31; b >= 0; b--) {
                putchar((rnd >> b) & 1 ? '1' : '0');
            }
        }
        putchar('\n');
        sleep_ms(DELAY_MS);
    }

    return 0;
}