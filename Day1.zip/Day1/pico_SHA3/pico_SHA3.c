#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "pico/stdlib.h"
#include "sha3.h"

#define MAX_INPUT_SIZE 1024

void bytes_to_hex(const uint8_t* bytes, size_t len, char* hex_str) {
    for (size_t i = 0; i < len; i++)
        sprintf(hex_str + (i * 2), "%02x", bytes[i]);
    hex_str[len * 2] = '\0';
}

// Read a single character (blocks until one arrives)
char getch(void) {
    int ch;
    while ((ch = getchar()) == EOF) {
        tight_loop_contents(); // wait
    }
    return (char)ch;
}

// Read a line by collecting characters until newline or timeout
int read_line(char* buffer, int max_len) {
    int len = 0;
    while (len < max_len - 1) {
        char ch = getch();
        if (ch == '\r' || ch == '\n') {
            if (len > 0) break;
            continue;
        }
        if (ch == '\b' || ch == 127) { // backspace
            if (len > 0) {
                len--;
                printf("\b \b");
            }
            continue;
        }
        buffer[len++] = ch;
        printf("%c", ch);
        fflush(stdout);
    }
    buffer[len] = '\0';
    printf("\n");
    return len;
}

void display_menu(void) {
    printf("\n=== Pico 2 SHA3 Hash Calculator ===\n");
    printf("1. SHA3-256\n2. SHA3-384\n3. SHA3-512\n");
    printf("Enter choice (1-3): ");
    fflush(stdout);
}

void perform_sha3(const char* input, int input_len, int mdlen, const char* name) {
    uint8_t hash[64];
    char hex[129];
    sha3(input, input_len, hash, mdlen);
    bytes_to_hex(hash, mdlen, hex);
    printf("\n%s: %s\n", name, hex);
}

int main() {
    stdio_init_all();
    sleep_ms(2000); 

    char input_buf[MAX_INPUT_SIZE];
    char choice_buf[16];

    read_line(choice_buf, sizeof(choice_buf));
    int choice = atoi(choice_buf);

    while (1) {    
        display_menu();
        read_line(choice_buf, sizeof(choice_buf));
        choice = atoi(choice_buf);

        printf("Enter text: ");
        int len = read_line(input_buf, MAX_INPUT_SIZE);

        if (len == 0)
            continue;

        switch (choice) {
            case 1:
                perform_sha3(input_buf, len, 32, "SHA3-256");
                break;

            case 2:
                perform_sha3(input_buf, len, 48, "SHA3-384");
                break;

            case 3:
                perform_sha3(input_buf, len, 64, "SHA3-512");
                break;

            default:
                printf("Invalid choice\n");
        }
    }
}